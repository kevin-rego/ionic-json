import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

  private firstnameobs = new BehaviorSubject<string>('');
  currentfirstnameobs = this.firstnameobs.asObservable();

  private lastnameobs = new BehaviorSubject<string>('');
  currentlastnameobs = this.lastnameobs.asObservable();

  private emailobs = new BehaviorSubject<string>('');
  currentemailobs = this.emailobs.asObservable();

  private idobs = new BehaviorSubject<string>('');
  currentidobs = this.idobs.asObservable();

  updateApprovalMessage(firstname: string, lastname: string,email:string) {
  this.firstnameobs.next(firstname);
  this.lastnameobs.next(lastname);
  this.emailobs.next(email);
}

updateId(id: any) {
  
  this.idobs.next(id);
}

getupdateid(){
  return this.currentidobs;
}

}
