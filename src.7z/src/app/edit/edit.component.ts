import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../data.service';




@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
})
export class EditComponent implements OnInit {

  firstname:any="";
  lastname:any="";
  email:any="";
  id:any;

  constructor(private modalCtrl: ModalController,private http:HttpClient,private dataService:DataService) { }

  ngOnInit() {
    this.dataService.currentidobs.subscribe(msg => this.id = msg)
  }
  


  onSubmit(){
    this.dataService.updateApprovalMessage(this.firstname,this.lastname, this.email);
    this.http.put('http://localhost:3000/users/'+this.id,{email: this.email, first_name : this.firstname, last_name : this.lastname, avatar:"https://ionicframework.com/docs/img/demos/avatar.svg"})
   .subscribe();    
  }

  cancel() {
    return this.modalCtrl.dismiss(null, 'cancel');
  }
}
