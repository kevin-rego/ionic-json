import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  id:number = 8;
  constructor(private http:HttpClient,public toastController: ToastController) {}
  firstname:string;
  lastname:string;
  email: string;
  avatar: string = "https://ionicframework.com/docs/img/demos/avatar.svg";
  @ViewChild('myForm') form: NgForm;


  onSubmit(){
    console.log(this.form);

    this.firstname = this.form.value.personDetails.firstname;
    this.lastname = this.form.value.personDetails.lastname;
    this.email = this.form.value.personDetails.email;
    this.avatar = "https://ionicframework.com/docs/img/demos/avatar.svg";
    this.postDetails(this.firstname, this.lastname, this.email, this.avatar);
    this.form.reset();
    this.presentToast();
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Your details have been added.',
      duration: 1500,
    });
    toast.present();
  }
  postDetails(fn, ln, em, av){
    this.id = this.id+1;
    this.http.post('http://localhost:3000/users', 
    {id: this.id, email: em, first_name : fn, last_name : ln, avatar: av}).subscribe((response)=>
    
    {
      console.log(response);
    });

  }
}
